var user = "Volvo";

function login() {
    var mail = document.getElementById("mail").value
    var password = document.getElementById("password").value

    if (mail == "Gene.Summers@sp.co" && password == "BigBrain"){
      window.location.href = 'user.html';
      user = "VFH-844";
    }
    else if (mail == "DarleneMeade@sp.co" && password == "Dar-lene"){
      window.location.href = 'user.html';
      user = "KNT-193";
    }
    else if (mail == "April.Wood@sp.co" && password == "a_maderos"){
      window.location.href = 'user.html';
      user = "OKM-287";
    }
    else if (mail == "Betty.Armstrong@sp.co" && password == "pelusita123"){
      window.location.href = 'user.html';
      user = "HFQ-571";
    }
    else if (mail == "Johnnie.Miles@sp.co" && password == "Johnniemelalavo"){
      window.location.href = 'user.html';
      user = "VAR-464";
    }
    else if (mail == "Sara.Wiley@sp.co" && password == "sara11"){
      window.location.href = 'user.html';
      user = "URJ-979";
    }
    else if (mail == "Jennifer.Borg@sp.co" && password == "JenniBor"){
      window.location.href = 'user.html';
      user = "KCD-324";
    }
    else if (mail == "Gregory.Urban@sp.co" && password == "AnamariaySanti5"){
      window.location.href = 'user.html';
      user = "RQW-566";
    }
    else if (mail == "Susan.Flores@sp.co" && password == "MotorolaG23"){
      window.location.href = 'user.html';
      user = "GFR-386";
    }
}
