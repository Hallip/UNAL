 function iniciarMap(){
    var coord = {lat: 4.733284 ,lng: -74.0527968};

    window.map = new google.maps.Map(document.getElementById('map'),{
      zoom: 10,
      center: coord
    });
    draw()
}

function error(err) {
  console.warn('ERROR(' + err.code + '): ' + err.message);
};


function success(pos) {
  var crd = pos.coords;
  var coord = {lat: crd.latitude, lng: crd.longitude};
  var coord2 = {lat: 4.590229900000001 ,lng: -74.11280959999999};
  var directionsRenderer = new google.maps.DirectionsRenderer();
  var directionsService = new google.maps.DirectionsService();

  var request = {
    origin: coord,
    destination: coord2,
    travelMode: 'DRIVING'
  };

  directionsRenderer.setMap(window.map)


  directionsService.route(request, function(result,status){
      if (status == "OK") {
          directionsRenderer.setDirections(result)
      }
  });
};

function draw(){
  var options = {
    enableHighAccuracy: true,
    timeout: 5000,
    maximumAge: 0
  };
  pos = (navigator.geolocation.getCurrentPosition(success, error, options))

}

function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else {
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}
